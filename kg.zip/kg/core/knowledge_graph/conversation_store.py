from __future__ import annotations

from typing import Any, Dict, Optional
from uuid import uuid4


class InMemoryIssueConversationStore:
    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}

    def create_conversation(
        self,
        tenant_id: str,
        initial_user_message: str,
        initial_assistant_message: Optional[str],
        selected_issue_id: Optional[str],
        selected_entity_type: Optional[str],
        selected_entity_id: Optional[str],
        selected_context: Optional[Dict[str, Any]],
        llm_context: Optional[Dict[str, Any]],
        hint: Optional[str] = None,
        mode: str = "issue_chat",
    ) -> Dict[str, Any]:
        conversation_id = str(uuid4())

        payload = {
            "conversation_id": conversation_id,
            "tenant_id": tenant_id,
            "hint": hint,
            "selected_issue_id": selected_issue_id,
            "selected_entity_type": selected_entity_type,
            "selected_entity_id": selected_entity_id,
            "selected_context": selected_context,
            "llm_context": llm_context,
            "messages": [
                {"role": "user", "content": initial_user_message},
                {"role": "assistant", "content": initial_assistant_message or ""},
            ],
            "mode": mode,
        }

        self._store[conversation_id] = payload
        return payload

    def get_conversation(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        return self._store.get(conversation_id)

    def append_message(self, conversation_id: str, role: str, content: str) -> Optional[Dict[str, Any]]:
        conv = self._store.get(conversation_id)
        if not conv:
            return None

        conv.setdefault("messages", []).append({
            "role": role,
            "content": content,
        })
        return conv

    def update_context(
        self,
        conversation_id: str,
        *,
        hint: Optional[str] = None,
        selected_issue_id: Optional[str] = None,
        selected_entity_type: Optional[str] = None,
        selected_entity_id: Optional[str] = None,
        selected_context: Optional[Dict[str, Any]] = None,
        llm_context: Optional[Dict[str, Any]] = None,
        mode: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        conv = self._store.get(conversation_id)
        if not conv:
            return None

        if hint is not None:
            conv["hint"] = hint
        if selected_issue_id is not None:
            conv["selected_issue_id"] = selected_issue_id
        if selected_entity_type is not None:
            conv["selected_entity_type"] = selected_entity_type
        if selected_entity_id is not None:
            conv["selected_entity_id"] = selected_entity_id
        if selected_context is not None:
            conv["selected_context"] = selected_context
        if llm_context is not None:
            conv["llm_context"] = llm_context
        if mode is not None:
            conv["mode"] = mode

        return conv


conversation_store = InMemoryIssueConversationStore()
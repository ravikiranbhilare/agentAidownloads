This contains all cases

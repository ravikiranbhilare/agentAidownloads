# test_resolve_issue.py
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict

import requests


def post_resolve_issue(
    base_url: str,
    tenant_id: str,
    message: str,
    limit: int,
    timeout: float,
) -> Dict[str, Any]:
    url = f"{base_url.rstrip('/')}/resolve_issue"
    payload = {"tenant_id": tenant_id, "message": message, "limit": limit}

    try:
        resp = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e

    # Raise for non-2xx (but still try to capture body for debugging)
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        body = resp.text.strip()
        raise RuntimeError(
            f"HTTP {resp.status_code} error from {url}\nResponse body: {body}"
        ) from e

    # Parse JSON response
    try:
        return resp.json()
    except ValueError as e:
        raise RuntimeError(
            f"Response was not valid JSON. Status={resp.status_code}, Body={resp.text[:500]}"
        ) from e


def main() -> int:
    parser = argparse.ArgumentParser(description="Test /resolve_issue and save result to JSON.")
    parser.add_argument("--base-url", default="http://localhost:8000", help="API base URL")
    parser.add_argument("--tenant-id", default="tenant_demo", help="Tenant ID")
    parser.add_argument("--message", default="QM scorecard drift across re-scores", help="Issue message")
    parser.add_argument("--limit", type=int, default=3, help="Limit")
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout seconds")
    parser.add_argument(
        "--out",
        default="resolve_issue_result.json",
        help="Output JSON path (or a directory to auto-name a file)",
    )
    args = parser.parse_args()

    result = post_resolve_issue(
        base_url=args.base_url,
        tenant_id=args.tenant_id,
        message=args.message,
        limit=args.limit,
        timeout=args.timeout,
    )

    out_path = Path(args.out)
    if out_path.exists() and out_path.is_dir():
        ts = time.strftime("%Y%m%d_%H%M%S")
        out_path = out_path / f"resolve_issue_{ts}.json"
    elif out_path.suffix.lower() != ".json":
        # If they pass something like "results/" that doesn't exist yet
        if str(out_path).endswith(("/", "\\")):
            out_path.mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            out_path = out_path / f"resolve_issue_{ts}.json"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"✅ Saved response to: {out_path}")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())